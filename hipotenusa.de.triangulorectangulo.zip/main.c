/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>
int main()
{
    int a,b;
    float  raiz;
    printf("Calcula la hipotenusa del triangulo rectangulo\n\n ");
    printf("\nDame el valor de a\n",a);
    scanf("%f",&a);
    printf("\nDame el valor de b\n",b);
    scanf("%f",&b);
    h = sqrt(pow(a,2)+pow(b,2));
printf("\nEl valor de la hipotenusa es  %.2f \n,",h);
    return 0;
}


