/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

int main()
{

    float a, b, c, d, e, f, x, y;
    printf("Escribe el valor del coeficiente a \n\n");
    scanf("%f",&a);
    printf("Escribe el valor del coeficiente b \n\n");
    scanf("%f",&b);
    printf("Escribe el valor del coeficiente c \n\n");
    scanf("%f",&c);
    printf("Escribe el valor del coeficiente d \n\n");
    scanf("%f",&d);
    printf("Escribe el valor del coeficiente e \n\n");
    scanf("%f",&e);
    printf("Escribe el valor del coeficiente f \n\n");
    scanf("%f",&f);
    x=(c*e-b*f)/(a*e-b*d);
    y=(a*f-c*d)/(a*e-b*d);
    printf("\n\nel valor de x es:\t%f",x);
  
    printf("\n\nel valor de y es:\t%f",y);
   
    
    
}
