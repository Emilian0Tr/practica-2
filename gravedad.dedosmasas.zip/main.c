/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<math.h>
#define G 6.673e-8

void main() {

	float m1, m2, d, fa;

    printf("Introduce 2 masas y la distancia que hay entre ellas\n");
	scanf("%f %f %f",&m1, &m2, &d);

	fa = (G*m1*m2)/pow(d,2);

	printf("\nLa fuerza de atraccion entre la masa 1 y la masa 2 es: %e", fa);


    return 0;
}

