
#include <stdio.h>
#include <stdlib.h> 
int main()
{
    int entero1, entero2, producto, cociente, residuo;
printf( "introduce el primer numero: \n\n");
scanf( "%d", &entero1);
printf("introduce el segundo numero: \n\n");
scanf("%d", &entero2);

//procesos
producto = entero1 * entero2;
cociente = entero1 / entero2; 
residuo = entero1 % entero2;
printf( "El producto es %d\n", producto );
printf( "El cociente %d\n", cociente );
printf( "El residuo %d\n", residuo );
system("pause"); 
}


